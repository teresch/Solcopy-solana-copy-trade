const RPC_URL = "https://api.mainnet-beta.solana.com";
const PRIVATE_KEY = "";
const MONITOR_WALLET = '';
const BUY_AMOUNT = 0.01;